<!DOCTYPE html>
<html lang="en">
<head>
    <title> Adamjee cantonment collage </title>
</head>
<body>
        <a href ='Studentlogin.php'>Student login</a><br>
        <a href ='studentregistration.php'>Student Registration</a><br>
        <a href ='teacherlogin.php'>Teachers login</a><br> 
        <a href ='Teacherregistration.php'>Teachers Registration</a><br>      
    <div>
        <h2 style="color:Green">Collage Campus </h2>
        <section>
        <img src="campus\25-March_Final.jpg"  width="300" hight = "300"><img src="campus\2817568453_b2cbd698b0_n.jpg"  width="300" hight = "300"> <img src="campus\Daily-sun-2017-03-26-NS-5.jpg"  width="300" hight = "300"><br>
        <img src="campus\download.jpg"  width="300" hight = "300"> <img src="campus\images (1).jpg"  width="300" hight = "300"> <img src="campus\images (2).jpg"  width="300" hight = "300">
        <img src="campus\images (3).jpg"  width="300" hight = "300"><img src="campus\images.jpg"  width="300" hight = "300"><img src="campus\maxresdefault.jpg"  width="300" hight = "300"><br>
        </section>
    </div>
    <footer>
        <p>  
            <h2>Adamjee cantonment collage</h1>
            <h3>ADDRESS: Dhaka cantonment</h2>
            <h3>EMAIL:ACC@GMAIL.COM</h3>
            <h3>PHONENUMBER:0123324809230</h4>
            <h4>Here leaders are created</h3>
            <h4>Good future depends on Education</h4><br>
            <a href= "">Need help</a><br>
        </p>
    </footer>
</body>
</html>