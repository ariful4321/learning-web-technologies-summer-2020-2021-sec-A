<!DOCTYPE html>
<html lang = "en">
<head>
        <title>Adamjee cantonment collage</title>
</head>
    <body>
    <form action="" method="POST">
        <table>
            <h2>Student Login</h2>
            <form action="" method="post">
            username/email <input type="text" name="uname"><br>
            password <input type="password" name="pass"><br>
            <input type="submit" name="submit">
        </table>
        <a href =''>Change Password</a><br>
        <a href =''>Forgot Password</a><br>
        <a href ='Homepage.php'>Home Page</a><br>
        <a href ='studentregistration.php'>Registration</a><br>
        <footer>
        <p>  
            <h2>Adamjee cantonment collage</h1>
            <h3>ADDRESS: Dhaka cantonment</h2>
            <h3>EMAIL:ACC@GMAIL.COM</h3>
            <h3>PHONENUMBER:0123324809230</h4>
            <h4>Here leaders are created</h3>
            <h4>Good future depends on Education</h4><br>
            <a href= "">Need help</a><br>
        </p>
    </footer>
</form>
    </body>
</html>