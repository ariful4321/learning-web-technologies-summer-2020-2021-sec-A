<!DOCTYPE html>
<html lang = "en">
<head>
        <title>Adamjee cantonment collage</title>
</head>
    <body>
    <form action="Sloginprocess.php" method="POST">
        <table>
            <h2>Student Registration</h2>
            <form action="" method="post">
            Student's Name <input type="text" name="name"><br>
            Student's FatherName <input type="text" name="fathername"><br>
            Student's MotherName <input type="text" name="Mothername"><br>
            Distict <input type="text" name="district"> Thana <input type="text" name="name"> Post office <input type="text" name="name"><br>
            Student Phone <input type="text" name="phone"><br>
            Student Gender <input type="radio" name="gender" value ="Male">MALE<input type="radio" name="gender" value ="female">FEMALE<br>
            Student Group <input type="radio" name="Group" value ="Science">Science<input type="radio" name="Group" value ="Commarce">Commarce<input type="radio" name="Group" value ="Arts">Arts<br>
            username/email <input type="text" name="uname"><br>
            password <input type="password" name="pass"><br>
            Confirm password <input type="password" name="cpass"><br>
            <input type="submit" name="submit">
        </table>
        Student Detail:<textarea id="Student Detail:" name="Student Detail"></textarea><br>
    </textarea><br>
        <footer>
        <p>  
            <h2>Adamjee cantonment collage</h1>
            <h3>ADDRESS: Dhaka cantonment</h2>
            <h3>EMAIL:ACC@GMAIL.COM</h3>
            <h3>PHONENUMBER:0123324809230</h4>
            <h4>Here leaders are created</h3>
            <h4>Good future depends on Education</h4><br>
            <a href= "">Need help</a><br>
        </p>
    </footer>
</form>
    </body>
</html>