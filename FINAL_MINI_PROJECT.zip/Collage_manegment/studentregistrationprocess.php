<?php            
                        if (isset($_POST["name"])) {
                            if (isset($_POST["phone"])) {
                                if (isset($_POST["gender"])) {
                                        if (isset($_POST["group"])) {
                                            if (isset($_POST["uname"])) {
                                                if (isset($_POST["pass"])) {
                                                    if (isset($_POST["cpass"])) {
                                                        if($_POST["pass"] == $_POST["cpass"]){

                                                        echo "Name:"," ",$_POST["name"];$_POST["gender"];
                                                        echo "Phone:",$_POST["phone"];
                                                        echo  "gender",$_POST["gender"];
                                                        echo "Group:"," ",$_POST["group"];
                                                        echo "USERNAME:"," ",$_POST["uname"];
                                                        echo "Password:"," ",$_POST["pass"];
                                                        echo "<br>";
                                        }else{
                                           echo "input detail" ;
                                           header("location:studentlogin.php");
                                        }
                                }else{
                                    echo "input detail" ;
                                    header("location:location:studentlogin.php");
                                }
                            }else{
                                echo "input wrong input"; 
                                header("location:studentlogin.php");
                            }
                        }else{
                            echo "input wrong input"; 
                            header("location:studentlogin.php");
                        }
                    }else{
                        echo "input wrong input"; 
                        header("location:studentlogin.php");
                    }
                }else{
                    echo "input wrong input"; 
                    header("location:studentlogin.php");
                }
            }else{
                echo "input wrong input"; 
                header("location:studentlogin.php");
            }
        }else{
            echo "input wrong input"; 
            header("location:studentlogin.php");
        }
    ?>